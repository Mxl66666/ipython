from src.Skill import Skill           
from src.Material import Material     
from src.Food import Food             
from src.Character import Character   
from src.Boss import Boss             
from src.Season import Season        
if __name__ == "__main__":
    print("===== 饥荒游戏核心逻辑演示 =====")

    # 1. 初始化季节系统（从春季开始，初始天数0）
    season_manager = Season(current_season="春", day_count=0)
    print(f"游戏开始，当前季节：{season_manager.current_season}")

    # 2. 创建玩家角色（威尔逊，初始状态：健康100，精神100，饥饿50）
    player = Character(
        health=100,
        sanity=100,
        hunger=50,
        inventory={},
        skills=[]
    )
    player.position = (10, 10)  # 初始位置
    print(f"\n玩家{player.__class__.__name__}初始化完成，初始位置：{player.position}")

    # 3. 创建基础物资（树枝、石头）和食物（浆果、肉）
    wood = Material(name="树枝", position=(8, 8), durability=30, quantity=5)
    stone = Material(name="石头", position=(12, 12), durability=40, quantity=3)
    berry = Food(name="浆果", position=(9, 9), hunger_value=10, spoilage=0)
    raw_meat = Food(name="生肉", position=(15, 15), hunger_value=25, spoilage=10)
    # 初始化季节效果需要的容器
    characters = [player]
    foods      = [berry, raw_meat]
    bosses     = []

    # 4. 玩家基础操作演示
    print("\n===== 玩家基础操作 =====")
    player.move((9, 9))  # 移动到浆果位置
    player.collect(berry)  # 采集浆果
    player.eat(berry)  # 食用浆果（恢复饥饿值）
    player.move((8, 8))
    player.collect(wood)  # 采集树枝
    player.collect(stone)  # 采集石头
    combined_axe = wood.combine(stone)  # 合成斧头
    if combined_axe:
        player.collect(combined_axe)  # 收集合成的斧头

    # 5. 技能系统演示
    print("\n===== 技能系统演示 =====")
    # 创建攻击技能（火球术）和增益技能（生命强化）
    fireball = Skill(
        name="火球术",
        skill_type="attack",
        cooldown=5,
        mana_cost=15,
        description="释放火球造成范围伤害",
        damage=20,
        range_=4
    )
    health_boost = Skill(
        name="生命强化",
        skill_type="buff",
        cooldown=10,
        mana_cost=10,
        description="短时间提升生命值上限",
        duration=30,
        stat_boost={"health": 20}
    )
    player.learn_skill(fireball)
    player.learn_skill(health_boost)
    player.use_skill("火球术")  # 使用攻击技能
    player.use_skill("生命强化")  # 使用增益技能

    # 6. BOSS系统演示（冬季BOSS：巨鹿）
    print("\n===== BOSS战斗演示 =====")
    bosses = []
    巨鹿_技能 = Skill(
        name="冰雪风暴",
        skill_type="attack",
        cooldown=8,
        mana_cost=0,
        description="大范围冰冻伤害",
        damage=30,
        range_=6
    )
    巨鹿 = Boss(
        name="巨鹿",
        position=(30, 30),
        health=300,
        attack_pattern="近战",
        season_spawn="冬",
        special_skills=[巨鹿_技能]
    )
    巨鹿.position = (30, 30)
    print(f"冬季BOSS【巨鹿】出现!位置:{巨鹿.position}")
    巨鹿.special_attack()  # 发动特殊攻击
    bosses.append(巨鹿)
    # 7. 季节变换及影响演示
    print("\n===== 季节系统演示 =====")
    for _ in range(3):  # 模拟3天春季
        season_manager.apply_effect(characters, foods, bosses)  # 应用当天季节效果（影响食物腐败等）
        berry.spoil(rate=2)  # 春季食物腐败较慢
        raw_meat.spoil(rate=2)
    season_manager.change_season()  # 切换到夏季
    print(f"\n季节切换为:{season_manager.current_season}")
    for _ in range(2):  # 模拟2天夏季
        season_manager.apply_effect(characters, foods, bosses)  # 夏季效果（食物腐败加速）
        berry.spoil(rate=5)  # 夏季腐败速率提升
        raw_meat.spoil(rate=5)

    print("\n===== 演示结束 =====")
