from typing import Tuple, Dict, List, TYPE_CHECKING
from .Material import Material
from .Food import Food

if TYPE_CHECKING:
    from .Skill import Skill

class Character:
    """角色基类：玩家控制角色"""

    def __init__(
        self,
        health: int = 100,
        sanity: int = 100,
        hunger: int = 100,
        inventory: Dict[str, Material] = None,
        skills: List["Skill"] = None,
        name: str = "Wilson",
        position: Tuple[int, int] = (0, 0),
    ):
        self.name = name
        self.position = position
        self.health = health
        self.sanity = sanity
        self.hunger = hunger
        # 默认空字典/列表，而非可变默认参数
        self.inventory: Dict[str, Material] = inventory or {}
        self.skills: List["Skill"] = skills or []

    def move(self, new_position: Tuple[int, int]) -> None:
        self.position = new_position
        print(f"{self.name} 移动到 {new_position}")

    def collect(self, material: Material) -> None:
        if material.name in self.inventory:
            self.inventory[material.name].quantity += material.quantity
        else:
            self.inventory[material.name] = material
        print(f"{self.name} 收集了 {material.quantity} 个 {material.name}")

    def eat(self, food: Food) -> None:
        if food.spoilage > 70:
            print(f"{food.name} 已严重腐败，无法食用")
            return
        self.hunger = min(100, self.hunger + food.hunger_value)
        # 确保 food 有 quantity 属性
        if hasattr(food, "quantity"):
            food.quantity -= 1
        print(f"{self.name} 食用了 {food.name}，饱食度变为 {self.hunger}")

    def learn_skill(self, skill: "Skill") -> None:
        self.skills.append(skill)
        print(f"{self.name} 学会了技能: {skill.name}")

    def use_skill(self, skill_name: str) -> None:
        for skill in self.skills:
            if skill.name == skill_name:
                skill.activate(self)
                return
        print(f"未学会技能: {skill_name}")

    def update(self) -> None:
        self.hunger = max(0, self.hunger - 1)
        self.sanity = max(0, self.sanity - 0.5)
        print(f"{self.name} 状态更新: 生命值 {self.health}, 精神值 {self.sanity}, 饱食度 {self.hunger}")

