from typing import Dict, TYPE_CHECKING

if TYPE_CHECKING:
    from .Character import Character

class Skill:
    """技能类：攻击/增益技能系统"""

    def __init__(
        self,
        name: str,
        skill_type: str,
        cooldown: int,
        mana_cost: int,
        description: str,
        damage: int = 0,
        range_: int = 0,
        duration: int = 0,
        stat_boost: Dict = None,
    ):
        self.name = name
        self.type = skill_type
        self.cooldown = cooldown
        self.mana_cost = mana_cost
        self.description = description
        self.damage = damage
        self.range = range_
        self.duration = duration
        self.stat_boost = stat_boost or {}

    def activate(self, caster: "Character") -> None:
        # 延迟导入，避免循环：如果真的需要 Character 类的属性或方法，
        # 在这里再导入也安全
        # from .Character import Character

        if caster.sanity < self.mana_cost:
            print(f"{caster.name} 精神值不足，无法释放 {self.name}")
            return

        caster.sanity -= self.mana_cost

        if self.type == "attack":
            print(f"{caster.name} 使用 {self.name}，造成 {self.damage} 点伤害，范围 {self.range}")
        elif self.type == "buff":
            print(f"{caster.name} 获得 {self.name} 增益，持续 {self.duration} 秒，属性提升: {self.stat_boost}")

