from typing import Tuple, Optional
class Material:
    """物资类：游戏中的基础物资（如树枝、石头）"""
    def __init__(self, name: str, position: Tuple[int, int], durability: int, quantity: int):
        self.name = name
        self.position = position
        self.durability = durability
        self.quantity = quantity

    def draw(self) -> None:
        """渲染物资到游戏画面"""
        print(f"渲染物资: {self.name} 在位置 {self.position}")

    def update(self) -> None:
        """更新物资状态（如耐久衰减）"""
        self.durability = max(0, self.durability - 1)  # 示例：每帧减少1点耐久
        print(f"更新物资 {self.name}，当前耐久: {self.durability}")

    def use(self) -> None:
        """使用物资（消耗耐久）"""
        if self.durability > 0:
            self.durability -= 5
            print(f"使用物资 {self.name}，剩余耐久: {self.durability}")
        else:
            print(f"物资 {self.name} 已耗尽")

    def combine(self, other: 'Material') -> Optional['Material']:
        """与其他物资合成新物品（示例逻辑）"""
        if (self.name == "树枝" and other.name == "石头") or (self.name == "石头" and other.name == "树枝"):
            print(f"合成新物资: 斧头")
            return Material("斧头", self.position, 100, 1)
        return None
