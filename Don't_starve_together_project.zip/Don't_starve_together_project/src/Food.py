from typing import Tuple

class Food:
    """食物类：可食用的物品（如浆果、肉干）"""
    def __init__(self, name: str, position: Tuple[int, int], hunger_value: int, spoilage: int, quantity: int = 1):
        self.name = name                  # 食物名称
        self.position = position          # 坐标位置
        self.hunger_value = hunger_value  # 饱食度恢复值
        self.spoilage = spoilage          # 腐败进度（0-100）
        self.quantity = quantity          # 数量，默认1

    def cook(self) -> None:
        """烹饪处理（提升饱食度）"""
        self.hunger_value = int(self.hunger_value * 1.5)
        self.spoilage = max(0, self.spoilage - 20)
        print(f"烹饪 [{self.name}]，饱食度变为 {self.hunger_value}，腐败度 {self.spoilage}%")

    def spoil(self, rate: float) -> None:
        """腐败效果（受季节影响）"""
        self.spoilage = min(100, self.spoilage + rate)
        print(f"[{self.name}] 腐败中，当前进度：{self.spoilage}%")
