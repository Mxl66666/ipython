from src.Character import Character
from src.Material import Material
from src.Skill import Skill
from typing import Tuple, List,Dict

class Boss(Character):
    def __init__(
            self,
        name: str,
        position: Tuple[int, int],
        health: int = 500,
        sanity: int = 100,
        hunger: int = 100,
        inventory: Dict[str, Material] = None,
        skills: List[Skill] = None,
        attack_pattern: str = "近战",
        season_spawn: str = "冬",
        special_skills: List[Skill] = None,
        sanity_impact: int = -50
    ):
        super().__init__(health, sanity, hunger, inventory, skills, name, position)
        self.attack_pattern = attack_pattern #近战或远程
        self.season_spawn = season_spawn    #诞生的季节
        self.special_skills = special_skills or []
        self.sanity_impact = sanity_impact
  # 对玩家精神值的影响

    def special_attack(self) -> None:
        """发动特殊技能攻击"""
        if self.special_skills:
            skill = self.special_skills[0]  # 示例：使用第一个特殊技能
            print(f"{self.name} 发动特殊攻击: {skill.name}，造成 {skill.damage * 2} 点伤害！")

    def update(self) -> None:
        """BOSS状态更新(强化版)"""
        super().update()
        # BOSS每帧恢复少量生命值
        self.health = min(500, self.health + 0.5)