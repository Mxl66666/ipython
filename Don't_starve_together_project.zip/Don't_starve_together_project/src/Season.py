from src.Character import Character
from src.Food import Food
from src.Skill import Skill
from src.Boss import Boss
from typing import List
class Season:
    """季节管理类：管理季节变换及影响"""
    def __init__(self, current_season="春", day_count=0):
        self.current_season = current_season  # 接收外部传入的初始季节
        self.day_count = day_count            # 接收外部传入的初始天数
        self.season_order = ["春", "夏", "秋", "冬"]


    def change_season(self) -> None:
        """切换到下一季节"""
        current_idx = self.season_order.index(self.current_season)
        self.current_season = self.season_order[(current_idx + 1) % 4]
        self.day_count = 0
        print(f"季节切换为: {self.current_season}")

    def apply_effect(self, characters: List[Character], foods: List[Food], bosses: List[Boss]) -> None:
        """应用季节效果(影响角色/食物/BOSS)"""
        self.day_count += 1
        print(f"\n【{self.current_season} 第 {self.day_count} 天】")

        # 季节对食物的影响
        for food in foods:
            if self.current_season == "夏":
                food.spoil(5)  # 夏季食物腐败快
            elif self.current_season == "冬":
                food.spoil(1)  # 冬季食物腐败慢
            else:
                food.spoil(2)  # 春秋正常速率

        # 季节对角色的影响
        for char in characters:
            if self.current_season == "冬":
                char.health = max(0, char.health - 1)  # 冬季低温掉血
            elif self.current_season == "夏":
                char.sanity -= 2  # 夏季高温掉精神

        # 季节BOSS生成判定
        if self.current_season == "冬" and self.day_count == 10:
            new_boss = Boss("巨鹿", (100, 100), "近战", "冬")
            new_boss.special_skills.append(Skill("冰刺冲击", "attack", 5, 0, "范围冰刺攻击", 50, 5))
            bosses.append(new_boss)
            print("冬季第10天,巨鹿出现!")

        # 季节BOSS活跃判定
        for boss in bosses:
            if boss.season_spawn == self.current_season and self.day_count % 5 == 0:
                boss.special_attack()  # 对应季节BOSS每5天发动一次特殊攻击
